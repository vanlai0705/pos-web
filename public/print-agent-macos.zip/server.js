#!/usr/bin/env node
"use strict"

/**
 * PosMobile Print Agent (macOS)
 *
 * A local HTTP bridge implementing the same tiny protocol the Windows
 * "PrinterService" install (from Cài đặt đơn hàng → "Tải về") already
 * speaks to the browser, so the "Đường dẫn cục bộ máy in" setting can point
 * at this instead:
 *
 *   GET  /Printer/GetInstalledPrinters        -> ["Printer A", "Printer B"]
 *   POST /Printer/PrintData                   -> { printerName, hostUrl, jsonData }
 *   POST /                                    -> same body shape (kitchen/label printers)
 *
 * For a print request: fetch `hostUrl` (POST `jsonData` as the body — this is
 * always the real api.posmobile.vn endpoint that renders the actual bill/PDF,
 * never content the browser sent directly), then hand the response bytes to
 * CUPS via `lp -d <printerName>`.
 */

const http = require("http")
const { execFile } = require("child_process")
const fs = require("fs")
const os = require("os")
const path = require("path")

const PORT = Number(process.env.PORT || process.argv[2] || 5000)

function withCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type")
}

function sendJson(res, status, body) {
  withCors(res)
  res.writeHead(status, { "Content-Type": "application/json" })
  res.end(JSON.stringify(body))
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on("data", c => chunks.push(c))
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")))
    req.on("error", reject)
  })
}

/** Lists CUPS print queues — the exact names `lp -d <name>` will accept. */
function listPrinters() {
  return new Promise(resolve => {
    execFile("lpstat", ["-p"], (err, stdout) => {
      if (err || !stdout) return resolve([])
      const names = []
      for (const line of stdout.split("\n")) {
        const m = line.match(/^printer\s+(\S+)/)
        if (m) names.push(m[1])
      }
      resolve(names)
    })
  })
}

const EXT_BY_CONTENT_TYPE = {
  "application/pdf": ".pdf",
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "text/plain": ".txt",
}

/** Fetches the rendered bill/ticket from `hostUrl` and sends it to CUPS. */
async function handlePrintRequest(bodyText) {
  let payload
  try {
    payload = JSON.parse(bodyText)
  } catch {
    throw new Error("invalid JSON body")
  }
  const { printerName, hostUrl, jsonData } = payload
  if (!printerName || !hostUrl) throw new Error("missing printerName/hostUrl")

  const upstream = await fetch(hostUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: jsonData ?? "{}",
  })
  if (!upstream.ok) throw new Error(`hostUrl fetch failed: ${upstream.status}`)

  const buf = Buffer.from(await upstream.arrayBuffer())
  const contentType = (upstream.headers.get("content-type") || "").split(";")[0].trim()
  const ext = EXT_BY_CONTENT_TYPE[contentType] || ".bin"
  const raw = ext === ".bin" // unrecognized content-type: assume raw ESC/POS bytes for a thermal printer
  const tmpFile = path.join(os.tmpdir(), `posmobile-print-${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`)

  await fs.promises.writeFile(tmpFile, buf)
  try {
    const lpArgs = raw ? ["-o", "raw", "-d", printerName, tmpFile] : ["-d", printerName, tmpFile]
    await new Promise((resolve, reject) => {
      execFile("lp", lpArgs, (err, stdout, stderr) => (err ? reject(new Error(stderr || err.message)) : resolve(stdout)))
    })
  } finally {
    fs.promises.unlink(tmpFile).catch(() => {})
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`)

  if (req.method === "OPTIONS") {
    withCors(res)
    res.writeHead(204)
    res.end()
    return
  }

  if (req.method === "GET" && url.pathname === "/Printer/GetInstalledPrinters") {
    const printers = await listPrinters()
    sendJson(res, 200, printers)
    return
  }

  if (req.method === "POST" && (url.pathname === "/Printer/PrintData" || url.pathname === "/")) {
    try {
      const body = await readBody(req)
      await handlePrintRequest(body)
      sendJson(res, 200, { Success: true })
    } catch (e) {
      console.error("[print-agent] print failed:", e.message)
      sendJson(res, 500, { Success: false, Message: e.message })
    }
    return
  }

  sendJson(res, 404, { Message: "Not found" })
})

server.on("error", err => {
  if (err.code === "EADDRINUSE") {
    console.error(`[print-agent] port ${PORT} đang bị chiếm (thường do AirPlay Receiver). Xem README.md để đổi cổng.`)
  } else {
    console.error("[print-agent] server error:", err.message)
  }
  process.exit(1)
})

server.listen(PORT, () => {
  console.log(`[print-agent] listening on http://0.0.0.0:${PORT}`)
  console.log(`[print-agent] set "Đường dẫn cục bộ máy in" to http://127.0.0.1:${PORT} (or this Mac's LAN IP)`)
})
