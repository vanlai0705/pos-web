#!/usr/bin/env bash
# Installs the PosMobile Print Agent as a background service on this Mac
# (auto-starts on login/boot via launchd, restarts if it crashes).
set -euo pipefail

APP_DIR="$HOME/PosMobilePrintAgent"
LOG_DIR="$APP_DIR/logs"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
PLIST_PATH="$LAUNCH_AGENTS_DIR/com.posmobile.printagent.plist"
PORT="${1:-5000}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v node >/dev/null 2>&1; then
  echo "Không tìm thấy Node.js. Vui lòng cài đặt trước (khuyến nghị dùng Homebrew):"
  echo "  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
  echo "  brew install node"
  exit 1
fi
NODE_BIN="$(command -v node)"

echo "Cài đặt vào: $APP_DIR"
mkdir -p "$APP_DIR" "$LOG_DIR"
cp "$SCRIPT_DIR/server.js" "$APP_DIR/server.js"
cp "$SCRIPT_DIR/package.json" "$APP_DIR/package.json"

mkdir -p "$LAUNCH_AGENTS_DIR"
sed \
  -e "s|__NODE_BIN__|$NODE_BIN|g" \
  -e "s|__SERVER_JS__|$APP_DIR/server.js|g" \
  -e "s|__PORT__|$PORT|g" \
  -e "s|__LOG_DIR__|$LOG_DIR|g" \
  "$SCRIPT_DIR/com.posmobile.printagent.plist.template" > "$PLIST_PATH"

launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
launchctl load -w "$PLIST_PATH"

sleep 1
if curl -sf "http://127.0.0.1:$PORT/Printer/GetInstalledPrinters" >/dev/null; then
  echo ""
  echo "✅ Đã cài đặt và khởi động thành công."
  echo "   Nhập vào ô \"Đường dẫn cục bộ máy in\" trong Cài đặt đơn hàng:"
  echo "   http://127.0.0.1:$PORT"
  echo "   (nếu máy chạy trình duyệt là một máy khác trong cùng mạng LAN, dùng địa chỉ IP LAN của Mac này thay cho 127.0.0.1)"
else
  echo ""
  echo "⚠️  Đã cài đặt nhưng chưa xác nhận được service đang chạy."
  echo "   Xem log lỗi tại: $LOG_DIR/print-agent.error.log"
fi
