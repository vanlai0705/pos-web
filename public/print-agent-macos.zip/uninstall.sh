#!/usr/bin/env bash
# Stops and removes the PosMobile Print Agent background service.
set -euo pipefail

APP_DIR="$HOME/PosMobilePrintAgent"
PLIST_PATH="$HOME/Library/LaunchAgents/com.posmobile.printagent.plist"

launchctl unload "$PLIST_PATH" >/dev/null 2>&1 || true
rm -f "$PLIST_PATH"
rm -rf "$APP_DIR"

echo "Đã gỡ Print Agent."
