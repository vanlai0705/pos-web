# PosMobile Print Agent (macOS)

Bản thay thế cho file "PrinterService" (nút **Tải về** trong *Cài đặt đơn hàng
→ Cấu hình máy in hoá đơn*) — file đó chỉ chạy được trên Windows. App này làm
đúng việc tương tự nhưng chạy trên macOS, dùng máy in đã cài trong **System
Settings → Printers & Scanners** của Mac (qua CUPS).

## Cài đặt (làm 1 lần)

1. Cài Node.js nếu máy chưa có (mở **Terminal**, dán lệnh sau nếu chưa có Homebrew):
   ```
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   brew install node
   ```
2. Copy cả thư mục `print-agent-macos` này vào Mac của cửa hàng.
3. Mở Terminal, vào thư mục đó rồi chạy:
   ```
   ./install.sh
   ```
   Muốn dùng cổng khác 5000 thì chạy `./install.sh 8000` (ví dụ).
4. Script sẽ in ra một địa chỉ dạng `http://127.0.0.1:5000` — copy dán vào ô
   **"Đường dẫn cục bộ máy in"** trong *Cài đặt đơn hàng*, rồi bấm **Lưu cài đặt**.
5. Bấm **Kiểm tra** — nếu thấy danh sách máy in hiện ra là đã kết nối thành công.
   Chọn máy in muốn dùng để in hoá đơn.

Sau bước này, app chạy nền vĩnh viễn (tự khởi động lại cùng máy, tự hồi phục
nếu bị tắt) — không cần mở lại Terminal mỗi ngày.

## Nếu trình duyệt bán hàng chạy trên máy khác trong cùng mạng LAN

Máy in phải cắm vào đúng Mac đang chạy Print Agent này. Khi đó, thay vì
`127.0.0.1`, dùng địa chỉ IP LAN của Mac đó (xem trong System Settings →
Wi-Fi/Network), ví dụ `http://192.168.1.50:5000`.

## Nếu cài lỗi vì cổng 5000 đã bị chiếm

macOS mặc định bật **AirPlay Receiver**, cũng dùng cổng 5000 — nếu bị đụng,
chọn 1 trong 2 cách:
- Tắt AirPlay Receiver: System Settings → General → AirDrop & Handoff → tắt
  "AirPlay Receiver".
- Hoặc dùng cổng khác khi cài: `./install.sh 8998` (nhớ đổi URL nhập vào
  "Đường dẫn cục bộ máy in" cho khớp cổng mới).

## Gỡ cài đặt

```
./uninstall.sh
```

## Xem log khi có lỗi in

```
tail -f ~/PosMobilePrintAgent/logs/print-agent.error.log
```

## Vì sao cần app riêng cho Mac?

File cài đặt tải qua nút "Tải về" là một service Windows đóng gói sẵn, không
chạy được trên macOS. App này expose đúng 2 API cục bộ mà giao diện bán hàng
đã gọi tới (`GetInstalledPrinters`, `PrintData`) — chỉ khác ở chỗ bên trong nó
in qua CUPS (hệ thống in chuẩn của macOS) thay vì API in của Windows.
